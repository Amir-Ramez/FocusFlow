using FocusFlow.Api.Data;
using FocusFlow.Api.DTOs;
using FocusFlow.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FocusFlow.Api.Services {
    public class GoalService {
        private readonly AppDbContext _context;
        private const long TempUserId = 1; // مؤقتاً لحين ربط الـ Authentication

        public GoalService(AppDbContext context) {
            _context = context;
        }

        public async Task<IEnumerable<GoalResponse>> GetGoalsAsync() {
            var goals = await _context.Goals
                .Where(g => g.UserId == TempUserId)
                .Include(g => g.Tasks)
                .ToListAsync();

            return goals.Select(MapToResponse);
        }

        public async Task<GoalResponse?> GetGoalByIdAsync(long id) {
            var goal = await _context.Goals
                .Include(g => g.Tasks)
                .FirstOrDefaultAsync(g => g.Id == id && g.UserId == TempUserId);

            return goal == null ? null : MapToResponse(goal);
        }

        public async Task<GoalResponse> CreateGoalAsync(CreateGoalRequest request) {
            if (string.IsNullOrWhiteSpace(request.Title)) {
                throw new ArgumentException("Goal title is required.");
            }

            var goal = new Goal {
                Title = request.Title,
                Description = request.Description,
                Status = request.Status ?? default,
                Deadline = request.Deadline,
                UserId = TempUserId,
                CreatedAt = DateTimeOffset.UtcNow,
                UpdatedAt = DateTimeOffset.UtcNow
            };

            _context.Goals.Add(goal);
            await _context.SaveChangesAsync();

            return MapToResponse(goal);
        }

        public async Task<GoalResponse?> UpdateGoalAsync(long id, UpdateGoalRequest request) {
            var goal = await _context.Goals
                .FirstOrDefaultAsync(g => g.Id == id && g.UserId == TempUserId);

            if (goal == null) {
                return null;
            }

            if (request.Title != null) {
                if (string.IsNullOrWhiteSpace(request.Title)) {
                    throw new ArgumentException("Goal title cannot be empty.");
                }
                goal.Title = request.Title;
            }

            if (request.Description != null) goal.Description = request.Description;
            if (request.Status.HasValue) goal.Status = request.Status.Value;
            if (request.Deadline != null) goal.Deadline = request.Deadline;

            goal.UpdatedAt = DateTimeOffset.UtcNow;
            await _context.SaveChangesAsync();

            return MapToResponse(goal);
        }

        public async Task<bool> DeleteGoalAsync(long id) {
            var goal = await _context.Goals
                .FirstOrDefaultAsync(g => g.Id == id && g.UserId == TempUserId);

            if (goal == null) {
                return false;
            }

            _context.Goals.Remove(goal);
            await _context.SaveChangesAsync();

            return true;
        }

        private static GoalResponse MapToResponse(Goal goal) {
            return new GoalResponse {
                Id = goal.Id,
                Title = goal.Title,
                Description = goal.Description,
                Status = goal.Status,
                Deadline = goal.Deadline,
                CreatedAt = goal.CreatedAt,
                UpdatedAt = goal.UpdatedAt
            };
        }
    }
}
