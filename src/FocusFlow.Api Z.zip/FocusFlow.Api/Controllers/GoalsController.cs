using FocusFlow.Api.DTOs;
using FocusFlow.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace FocusFlow.Api.Controllers {
    [Route("goals")]
    [ApiController]
    public class GoalsController : ControllerBase {
        private readonly GoalService _goalService;

        public GoalsController(GoalService goalService) {
            _goalService = goalService;
        }

        // GET /goals
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GoalResponse>>> GetGoals() {
            var goals = await _goalService.GetGoalsAsync();
            return Ok(goals);
        }

        // GET /goals/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<GoalResponse>> GetGoalById(long id) {
            var goal = await _goalService.GetGoalByIdAsync(id);
            if (goal == null) {
                return NotFound(new { message = "Goal not found." });
            }
            return Ok(goal);
        }

        // POST /goals
        [HttpPost]
        public async Task<IActionResult> CreateGoal([FromBody] CreateGoalRequest request) {
            try {
                var createdGoal = await _goalService.CreateGoalAsync(request);
                return CreatedAtAction(nameof(GetGoalById), new { id = createdGoal.Id }, createdGoal);
            }
            catch (ArgumentException ex) {
                return BadRequest(new { message = ex.Message });
            }
        }

        // PUT /goals/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateGoal(long id, [FromBody] UpdateGoalRequest request) {
            try {
                var updatedGoal = await _goalService.UpdateGoalAsync(id, request);
                if (updatedGoal == null) {
                    return NotFound(new { message = "Goal not found." });
                }
                return Ok(updatedGoal);
            }
            catch (ArgumentException ex) {
                return BadRequest(new { message = ex.Message });
            }
        }

        // DELETE /goals/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGoal(long id) {
            var deleted = await _goalService.DeleteGoalAsync(id);
            if (!deleted) {
                return NotFound(new { message = "Goal not found." });
            }
            return NoContent();
        }
    }
}
